# EDA-on-Titanic-Dataset---

EDA on Titanic Dataset - Performed EDA and made some observations on how factors like 'Age', 'Gender', 'Coach Position', 'Embarked Place', 'Destination Place' affects the survival of person in Titanic Accident. Applied Machine Learning models and compared them based on accuracy. Used Cross validation techniques to deal with Bias.
